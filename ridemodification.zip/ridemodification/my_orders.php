<center>
    
    <h1> My Orders </h1>
    
    <p class="lead"> Your orders on one place</p>
    
    <p class="text-muted"> If you have any question, feel free to <a href="contact.php">Contact us</a>. Our Customer Service work <strong>24/7.</strong></p>
    
</center>


<hr>


<div class="table-responsive">
    
    <table class="table table-bordered table-hover">
        
        <thead>
            
            <tr>
                
                <th> ON:</th>
                <th> Due Amount: </th>
                <th> Invoice No: </th>
                <th> Qty: </th>
                <th> Make:</th>
                <th> Order Date: </th>
                <th> Paid / Unpaid: </th>
                <th> Status: </th>
                
            </tr>
            
        </thead>
        
        <tbody>
            
            <tr>
                
            <th> #1 </th>
            <td> Pkr 1000 </td>
            <td> 3687452 </td>
            <td> 2 </td>
            <td> Honda </td>
            <td> 18-03-2020 </td>
            <td> Unpaid </td>
            <td>
                
               <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm Paid</a> 
                
            </td>
             
            </tr>
             <tr>
                
            <th> #1 </th>
            <td> Pkr 1000 </td>
            <td> 3687452 </td>
            <td> 2 </td>
            <td> Honda </td>
            <td> 18-03-2020 </td>
            <td> Unpaid </td>
            <td>
                
               <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm Paid</a> 
                
            </td>
             
            </tr>
            
             <tr>
                
            <th> #1 </th>
            <td> Pkr 1000 </td>
            <td> 3687452 </td>
            <td> 2 </td>
            <td> Honda </td>
            <td> 18-03-2020 </td>
            <td> Unpaid </td>
            <td>
                
               <a href="confirm.php" target="_blank" class="btn btn-primary btn-sm">Confirm Paid</a> 
                
            </td>
             
            </tr>
            
        </tbody>
        
    </table>
    
</div>