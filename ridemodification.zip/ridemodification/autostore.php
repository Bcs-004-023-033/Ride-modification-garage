<?php

include("includes/db.php");
include("functions/functions.php");

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
    <title>Ride Modification Garage</title>
    
<!--bootstrap-->
    
    <link type="text/css" rel="stylesheet" href="bootstrap-4.4.1-dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="style.css" />
    <link type="text/css" rel="stylesheet" href="autostore.css" />
    <link  rel="stylesheet" href="css/all.min.css" >
    <link rel="stylesheet" href="css/fontawesome.min.css">
    
    </head>
    <body>
      
        <?php include'header.php';?>
          <div id="content">
           <div class="container">
               <div class="col-md-13">
                   
                 <ul class="breadcrumb">
                     <li>
                         <a href="autostore.php">Home</a>
                     </li>
                     <li>
                         Autostore
                     </li>
                    
                 </ul>  
                   
               </div>
               
               <div class="col-md-3">
                   
             <div class="main">
      <div class="sidenav" >
     <h3>Categories</h3>   
  <a href="exterior.php">Exterior </a>
  <a href="exterior.php">Interior </a>
  <a href="gadgets.php">Gadgets</a>
  <a href="wraps.php">Wraps</a>
  <a href="lights.php">Lights</a>
</div>
                   
               </div>
               
           </div>
       </div>
        </div> 
    
   <div class="container" id="slider"><!-- container Begin -->
       
       <div class="col-md-12"><!-- col-md-12 Begin -->
           
           <div class="carousel slide" id="myCarousel" data-ride="carousel"><!-- carousel slide Begin -->
               
               <ol class="carousel-indicators"><!-- carousel-indicators Begin -->
                   
                   <li  data-target="myCarousel" data-slide-to="0" class="active"></li>
                   <li data-target="myCarousel" data-slide-to="1"></li>
                   <li data-target="myCarousel" data-slide-to="2"></li>
                   <li data-target="myCarousel" data-slide-to="3"></li>
                 
               </ol><!-- carousel-indicators Finish -->
               
               <div class="carousel-inner"><!-- carousel-inner Begin -->
                  <?php
                   
                $get_slider="select * from slider LIMIT 0,1";
                 $run_slider=mysqli_query($con,$get_slider);
                   
                   while($row=mysqli_fetch_array($run_slider)){
                       
                       $slider_name=$row['slider_name'];
                       $slider_image=$row['slider_image'];
                       
                       echo "
                       
                       <div class='carousel-item active'>
                       
                       <img src='admin/slidesauto/$slider_image'>
                       
                       </div>
                       
                       ";
                       
                   }
                   
                 
                $get_slider="select * from slider LIMIT 1,3";
                 $run_slider=mysqli_query($con,$get_slider);
                   
                   while($row=mysqli_fetch_array($run_slider)){
                       
                       $slider_name=$row['slider_name'];
                       $slider_image=$row['slider_image'];
                       
                       echo "
                       
                       <div class='carousel-item'>
                       
                       <img src='admin/slidesauto/$slider_image'>
                       
                       </div>
                       
                       ";
                       
                   }
                   
                   ?> 
                  
                   
               </div><!-- carousel-inner Finish -->
              <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		</a>
               
           </div><!-- carousel slide Finish -->
           
       </div><!-- col-md-12 Finish -->
       
   </div><!-- container Finish -->
   
   <div id="advantages"><!-- #advantages Begin -->
       
       <div class="container"><!-- container Begin -->
           
           <div class="row same-height"><!-- same-height-row Begin -->
               
               <div class="col-sm-4"><!-- col-sm-4 Begin -->
                   
                   <div class="box same-height"><!-- box same-height Begin -->
                       
                       <div class="icon"><!-- icon Begin -->
                           
                           <i class="fa fa-heart"></i>
                           
                       </div><!-- icon Finish -->
                       
                       <h3><a href="#">Best Offer</a></h3>
                       
                       <p>We know to provide the best possible service</p>
                       
                   </div><!-- box same-height Finish -->
                   
               </div><!-- col-sm-4 Finish -->
               
               <div class="col-sm-4"><!-- col-sm-4 Begin -->
                   
                   <div class="box same-height"><!-- box same-height Begin -->
                       
                       <div class="icon"><!-- icon Begin -->
                           
                           <i class="fa fa-tag"></i>
                           
                       </div><!-- icon Finish -->
                       
                       <h3><a href="#">Best Prices</a></h3>
                       
                       <p>We have the best reasonable price</p>
                       
                   </div><!-- box same-height Finish -->
                   
               </div><!-- col-sm-4 Finish -->
               
               <div class="col-sm-4"><!-- col-sm-4 Begin -->
                   
                   <div class="box same-height"><!-- box same-height Begin -->
                       
                       <div class="icon"><!-- icon Begin -->
                           
                           <i class="fa fa-thumbs-up"></i>
                           
                       </div><!-- icon Finish -->
                       
                       <h3><a href="#">100% Original</a></h3>
                       
                       <p>We just offer you the best</p>
                       
                   </div><!-- box same-height Finish -->
                   
               </div><!-- col-sm-4 Finish -->
               
           </div><!-- same-height-row Finish -->
           
       </div><!-- container Finish -->
       
   </div><!-- #advantages Finish -->
  
  <div id="hot">
      
      <div class="box">
          
          <div class="container">
              
              <div class="col-md-12">
                  
                  
                     Our Latest Products
                  
                  
              </div>
              
          </div>
          
      </div>
      
  </div>
   
   <div id="content" class="container">
       
       <div class="row">
           
           
          <?php getPro();?>
           
         
        
       </div>
       
   </div>
     


      <?php include'footer.php' ;?>
      
      
       
    <script src="bootstrap-4.4.1-dist/js/bootstrap.min.js"></script>
    <script src="js/jquery.min.js"></script>
     
    
    </body>
    
    
</html> 

