   <div class="footer">
     <div class="container">
        <div class="row">
         <div class="col-md-3">
            <h1>Useful Links</h1>
             <p>Privacy Policy</p>
             <p>Terms of Use</p>
             <p>Return Policy</p>
             <p>Discount Coupons</p>
            
            </div>
          <div class="col-md-3">
            <h1>Company</h1>
             <p>About Us</p>
             <p>Contact Us</p>
             <p>Product Partners</p>
            
            </div>
          <div class="col-md-3">
            <h1>Follow Us On</h1>
             <p><i class="fab fa-facebook-square"></i>Facebook</p>
             <p><i class="fab fa-youtube"></i>Youtube</p>
             <p><i class="fab fa-linkedin"></i>LinkedIin</p>
             <p><i class="fab fa-twitter"></i>Twitter</p>
         </div>
        <div class="col-md-3 footer-image">
            <h1>Download App</h1>
             <img src="images/features/playstore.png" id="play">
            
            </div>
        </div>
    <hr>
         <p class="copyright">Ride Modification Garge<i class="far fa-registered"></i>Made in 2020</p>
    </div>
    </div>