<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
    <title>Ride Modification Garage</title>
    
<!--bootstrap-->
    
    <link type="text/css" rel="stylesheet" href="bootstrap-4.4.1-dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="style.css" />
     <link type="text/css" rel="stylesheet" href="autostore.css" />
    <link  rel="stylesheet" href="css/all.min.css" >
    <link rel="stylesheet" href="css/fontawesome.min.css">
    
    </head>
    <body>
        <?php include'header.php';?>
       
       
       <div id="content">
           <div class="container">
               <div class="col-md-12">
                   
                 <ul class="breadcrumb">
                     <li>
                         <a href="autostore.php">Home</a>
                     </li>
                     <li>
                         <a href="autostore.php">Autostore</a>
                     </li>
                     <li>
                        Register 
                     </li>
                 </ul>  
                   
               </div>
               <div class="d-flex">
               <div class="col-md-3">
                  
                  
                   <?php include'sidebar.php';?>
                   
               </div> 
                <div class="col-md-9">
                      
                   <div class="box">
                       
                       <div class="box-header" id="contact">
                           
                           <center>
                               
                               <h2> Register a new account</h2>
                               
                               
                           </center>
                       
                           <form action="register.php" method="post" enctype="multipart/form-data">
                               
                               <div class="form-group">
                                   
                                   <label>Your Name</label>
                                   
                                   <input type="text" class="form-control" name="yname" required>
                                   
                               </div>
                               
                               <div class="form-group">
                                   
                                   <label>Your Email</label>
                                   
                                   <input type="text" class="form-control" name="y_email" required>
                                   
                               </div>
                               <div class="form-group">
                                   
                                   <label>Your Password</label>
                                   
                                   <input type="password" class="form-control" name="y_pass" required>
                                   
                               </div>
                                <div class="form-group">
                                   
                                   <label>Your City</label>
                                   
                                   <input type="text" class="form-control" name="y_city" required>
                                   
                               </div>
                                <div class="form-group">
                                   
                                   <label>Your Contact</label>
                                   
                                   <input type="text" class="form-control" name="y_contact" required>
                                   
                               </div>
                                <div class="form-group">
                                   
                                   <label>Your Address</label>
                                   
                                   <input type="text" class="form-control" name="y_address" required>
                                   
                               </div>
                                <div class="form-group">
                                   
                                   <label>Your Profile Picture</label>
                                   
                                   <input type="file" class="form-control form-height-custom" name="y_image" required>
                                   
                               </div>
                               
                               
                               <div class="text-center">
                                   
                                   <button type="submit" name="register" class="btn btn-primary">
                                       
                                       <i class="fa fa-user-md"></i> Register
                                       
                                   </button>
                                   
                                   
                                   
                               </div>
                               
                           </form>
                           
                       </div>
                       
                   </div>   
                      
                  </div>
                              
           </div>             
     </div>
   
        </div>
       
        <?php include'footer.php';?>
        
        
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.min.js"></script>
       
    </body>
    
    
</html> 