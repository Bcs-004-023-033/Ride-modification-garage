<?php

include("includes/db.php");
include("functions/functions.php");

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
    <title>Ride Modification Garage</title>
    
<!--bootstrap-->
    
    <link type="text/css" rel="stylesheet" href="bootstrap-4.4.1-dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="style.css" />
     <link type="text/css" rel="stylesheet" href="autostore.css" />
    <link  rel="stylesheet" href="css/all.min.css" >
    <link rel="stylesheet" href="css/fontawesome.min.css">
    
    </head>
    <body>
        <?php include'header.php';?>
       
       
       <div id="content">
           <div class="container">
               <div class="col-md-12">
                   
                 <ul class="breadcrumb">
                     <li>
                         <a href="autostore.php">Home</a>
                     </li>
                     <li>
                         <a href="autostore.php">Autostore</a>
                     </li>
                     <li>
                        My Account
                     </li>
                 </ul>  
                   
               </div>
               <div class="d-flex">
               <div class="col-md-3">
                  
                  
                   <?php include'accsidebar.php';?>
                   
               </div> 
                                            
                <div class="col-md-9">
                    
                    <div class="box">
                        
                        <?php if(isset($_GET['my_orders'])){
    include("my_orders.php");
    
}
                        ?>
                        
                         <?php if(isset($_GET['pay_offline'])){
    include("pay_offline.php");
    
}
                        ?>
                        
                          <?php if(isset($_GET['edit_account'])){
    include("edit_account.php");
    
}
                        ?>
                        
                         <?php if(isset($_GET['change_pass'])){
    include("change_pass.php");
    
}
                        ?>
                        
                            <?php if(isset($_GET['dlt_account'])){
    include("dlt_account.php");
    
}
                        ?>
                    </div>
                    
                </div>                            
                                             
           </div>             
     </div>
   
        </div>
       
        <?php include'footer.php';?>
        
        
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.min.js"></script>
       
    </body>
    
    
</html> 