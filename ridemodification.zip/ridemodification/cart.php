<?php

include("includes/db.php");
include("functions/functions.php");

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
    <title>Ride Modification Garage</title>
    
<!--bootstrap-->
    
    <link type="text/css" rel="stylesheet" href="bootstrap-4.4.1-dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="style.css" />
     <link type="text/css" rel="stylesheet" href="autostore.css" />
    <link  rel="stylesheet" href="css/all.min.css" >
    <link rel="stylesheet" href="css/fontawesome.min.css">
    
    </head>
    <body>
        <?php include'header.php';?>
       
       
       <div id="content">
           <div class="container">
               <div class="col-md-12">
                   
                 <ul class="breadcrumb">
                     <li>
                         <a href="autostore.php">Home</a>
                     </li>
                     <li>
                         <a href="autostore.php">Autostore</a>
                     </li>
                     <li>
                        Cart 
                     </li>
                 </ul>  
                   
               </div>
              <div class="d-flex">
               <div id="cart" class="col-md-9">
                   
                      <div class="box">
                          
                         <form action="cart.php" method="post" enctype="multipart/form-data">
                             
                             <h1>Shopping Cart</h1>
                             <p class="text-muted">You currently have 3 item(s) in your cart</p>
                             
                             <div class="table-responsive">
                                 
                               <table class="table">
                                   
                                   <thead>
                                       
                                       <tr>
                                           
                                           <th colspan="2">Product</th>
                                           <th>Quantity</th>
                                           <th>Unit Price</th>
                                           <th>Make</th>
                                           <th colspan="1">Delete</th>
                                           <th colspan="2">Sub-Total</th>
                                           
                                       </tr>
                                       
                                   </thead>
                                   
                                   <tbody>
                                       
                                       <tr>
                                           
                                           <td>
                                               
                                               <img class="img-fluid" src="admin/parts/exterior/mirror.jpg" alt="Product 1">
                                               
                                           </td>
                                           
                                           <td>
                                               
                                               <a href="#">Side Mirror</a>
                                               
                                           </td>
                                           
                                           <td>
                                               2
                                           </td>
                                           
                                           <td>
                                               
                                               Pkr 1000
                                               
                                           </td>
                                           
                                           <td>
                                               
                                               Honda
                                               
                                           </td>
                                           
                                           <td>
                                               
                                               <input type="checkbox" name="remove[]">
                                               
                                           </td>
                                           
                                           <td>
                                               
                                            Pkr 2000
                                               
                                           </td>
                                           
                                       </tr>
                                       
                                   </tbody>
                                    <tbody>
                                       
                                       <tr>
                                           
                                           <td>
                                               
                                               <img class="img-fluid" src="admin/parts/exterior/part1.jpg" alt="Product 1">
                                               
                                           </td>
                                           
                                           <td>
                                               
                                               <a href="#">Diffuser</a>
                                               
                                           </td>
                                           
                                           <td>
                                               2
                                           </td>
                                           
                                           <td>
                                               
                                               Pkr 1000
                                               
                                           </td>
                                           
                                           <td>
                                               
                                               Honda
                                               
                                           </td>
                                           
                                           <td>
                                               
                                               <input type="checkbox" name="remove[]">
                                               
                                           </td>
                                           
                                           <td>
                                               
                                            Pkr 2000
                                               
                                           </td>
                                           
                                       </tr>
                                       
                                   </tbody>
                                    <tbody>
                                       
                                       <tr>
                                           
                                           <td>
                                               
                                               <img class="img-fluid" src="admin/parts/exterior/part6.jpg" alt="Product 1">
                                               
                                           </td>
                                           
                                           <td>
                                               
                                               <a href="#">Bumper Styling</a>
                                               
                                           </td>
                                           
                                           <td>
                                               2
                                           </td>
                                           
                                           <td>
                                               
                                               Pkr 1000
                                               
                                           </td>
                                           
                                           <td>
                                               
                                               Honda
                                               
                                           </td>
                                           
                                           <td>
                                               
                                               <input type="checkbox" name="remove[]">
                                               
                                           </td>
                                           
                                           <td>
                                               
                                            Pkr 2000
                                               
                                           </td>
                                           
                                       </tr>
                                       
                                   </tbody>
                                   
                                   <tfoot>
                                       
                                      <tr>
                                          
                                          <th colspan="5">Total</th>
                                          <th colspan="2">$2000</th>
                                          
                                      </tr> 
                                       
                                   </tfoot>
                                   
                               </table>  
                                 
                             </div>
                             
                             <div class="box-footer">
                                 
                                 <div class="float-left">
                                     
                                     <a href="autostore.php" class="btn btn-primary">
                                         
                                         <i class="fa fa-chevron-left"></i> Continue Shopping
                                         
                                     </a>
                                     
                                 </div>
                                 <div class="float-right">
                                     
                                     <button type="submit" name="update" value="update cart" class="btn btn-primary">
                                         
                                         <i class="fa fa-sync-alt"></i> Update Cart
                                         
                                     </button>
                                     
                                     <a href="checkout.php" class="btn btn-primary">
                                         
                                         Proceed Checkout <i class="fa fa-chevron-right"></i>
                                         
                                     </a>
                                     
                                 </div>
                                 
                             </div>
                             
                         </form> 
                          
                      </div>
                      
                       <div class="row same-height-row">
                      <div class="col-md-3 col-sm-6">
                          <div class="box same-height headline">
                              <h3 class="text-center">Products you may like</h3>
                          </div>
                      </div>
                      
                      <div class="col-md-3 col-sm-6 center-block">
                          <div class="product same-height">
                          <a href="details.php">
                             <img class="img-fluid" src="admin/parts/exterior/part1.jpg" alt="Product 2">
                          </a>
                          
                          <div class="text">
                              <h3><a href="details.php">Diffuser</a></h3>
                              
                              <p class="price">Pkr 1100</p>
                              
                          </div>
                          
                          </div>
                      </div>
                       <div class="col-md-3 col-sm-6 center-block">
                          <div class="product same-height">
                          <a href="details.php">
                             <img class="img-fluid" src="admin/parts/exterior/part2.jpg" alt="Product 2">
                          </a>
                          
                          <div class="text">
                              <h3><a href="details.php">Bumper</a></h3>
                              
                              <p class="price">Pkr 1100</p>
                              
                          </div>
                          
                          </div>
                      </div>
                      <div class="col-md-3 col-sm-6 center-block">
                          <div class="product same-height">
                          <a href="details.php">
                             <img class="img-fluid" src="admin/parts/exterior/part6.jpg" alt="Product 2">
                          </a>
                          
                          <div class="text">
                              <h3><a href="details.php">Bumper Styling</a></h3>
                              
                              <p class="price">Pkr 1100</p>
                              
                          </div>
                          
                          </div>
                      </div>
                      
                  </div>
                  
                </div>
                  
                  <div class="col-md-3">
                      
                      <div id="order-summary" class="box">
                          
                          <div class="box-header">
                              
                              <h3>Order Summary</h3>
                              
                          </div>
                          
                          <p class="text-muted">
                              
                              Shipping and additional costs are calculated on value you have entered
                              
                          </p>
                          
                          <div class="table-responsive">
                              
                              <table class="table">
                                  
                                  <tbody>
                                      
                                      <tr>
                                          
                                          <td> Order Sub-Total </td>
                                          <th> Pkr 2200  </th>
                                          
                                      </tr>
                                      
                                      <tr>
                                          
                                          <td> Shipping and Handling </td>
                                          <td> Pkr 0 </td>
                                          
                                      </tr>
                                      
                                      <tr>
                                          
                                          <td> Tax </td>
                                          <td> Pkr 0 </td>
                                          
                                      </tr>
                                       <tr class="total">
                                          
                                          <td> Total </td>
                                          <td> Pkr 2200 </td>
                                          
                                      </tr>
                                      
                                  </tbody>
                                  
                              </table>
                              
                          </div>
                          
                      </div>
                      
                  </div>
                  
                </div>
               </div>
               
           </div>
      
               <?php include'footer.php';?>
        
        
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.min.js"></script>
       
    </body>
    
    
</html> 