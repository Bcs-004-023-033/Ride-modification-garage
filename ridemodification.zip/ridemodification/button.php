<head>
    <style>
          .buttonc {
  background-color:green; /* Green */
  border-radius: 50%;
  padding: 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
              
}
        
        .buttonr {
 
  border-radius: 50%;
 
  display: inline-block;
  
  cursor: pointer;
              
}
        
        
        h1{
            background-color: lightgray;
        }       

.button1 {border-radius: 50%;background-color: red;}
.button2 {border-radius: 50%;background-color: blue;}
.button3 {border-radius: 50%;background-color: black;}
.button4 {border-radius: 50%;background-color: darkgoldenrod;}

    
    </style>
</head>
<br>
            <center> <h1><img src="images/180.png" width="80" height="50"> 180 degree VIEW </h1> </center>
        <br>
        
        <a href="modify.php"> <img src="images/btnimage/corolla.png" width="160" height="90"> </a>

         <a href="gwagon.php"> <img src="images/btnimage/gwagon.png" width="160" height="90"> </a>

        <a href="buggati.php"> <img src="images/btnimage/swift.png" width="160" height="90"></a>
        
          <a href="cobra.php"><img src="images/btnimage/cobra.png" width="160" height="90"> </a>

        <a href="sportage.php"> <img src="images/btnimage/sportage.png" width="160" height="90"> </a>

        
        <a href="bmw3.php"> <img src="images/btnimage/bmw3.png" width="160" height="90"> </a>
        
         <a href="rangen.php"> <img src="images/btnimage/range.png" width="160" height="90"> </a>
        
         <a href="lamboghini.php"> <img src="images/btnimage/lambo.png" width="160" height="90"></a>
        
         <a href="range.php"><img src="images/btnimage/range2.png" width="160" height="90"></a>
        
         <a href="dodgeold.php"><img src="images/btnimage/dodge.png" width="160" height="90"> </a>
        
          <a href="camaro.php"> <img src="images/btnimage/camaro.png" width="160" height="90"></a>
        
          <a href="evo.php"> <img src="images/btnimage/Evo.png" width="160" height="90"> </a>
        
          <a href="volks.php"> <img src="images/btnimage/volks2.png" width="160" height="90"> </a>
        
         <a href="bmw5.php"> <img src="images/btnimage/bmw5.png" width="160" height="90"> </a>
        
        <a href="soarer.php"> <img src="images/btnimage/soarer.png" width="160" height="90"> </a>
         
        
        <div>
             
      <center> 
          <h1> WRAP colors </h1>     
             
<button class="buttonc button1" onclick="myFunctionred()"></button>
<button class="buttonc button2" onclick="myFunctionblue()"></button>
<button class="buttonc button3" onclick="myFunctionblack()"></button>
<button class="buttonc button4" onclick="myFunctiongold()"></button>
<button class="buttonc button5" onclick="myFunctionsilver()"></button>
          </center>   
        </div>
            

<div>
    <center>
        <h1> RIMS </h1> 
        
<button class="buttonr button6" onclick="myFunctionr1()"><img src="images/btnimage/r1.PNG" width="80" height="65"></button>
<button class="buttonr button7" onclick="myFunctionr3()"><img src="images/btnimage/r3.PNG" width="80" height="65"></button>
<button class="buttonr button8" onclick="myFunctionr5()"><img src="images/btnimage/r5.PNG" width="80" height="65"></button>
<button class="buttonr button9" onclick="myFunctionR6()"><img src="images/btnimage/r6.PNG" width="80" height="65"></button>
        <h1> 
        SPOILER</h1>
        
<button class="buttonr button10" onclick="myFunctions2()"><img src="images/btnimage/s2.png" width="80" height="65"></button>
<button class="buttonr button11" onclick="myFunctions3()"><img src="images/btnimage/s3.png" width="80" height="65"></button>
        </center>
        
         
</div>