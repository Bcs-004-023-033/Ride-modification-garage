<center>
    
    <h1> Pay Offline using method </h1>
    
    <p class="text-muted"> If you have any question, feel free to <a href="contact.php">Contact us</a>. Our Customer Service work <strong>24/7.</strong></p>
    
</center>


<div class="table-responsive">
    
    <table class="table table-bordered table-hover table-striped">
        
        <thead>
            
            <tr>
                
              <th> Easy Paisa Account Details: </th>
               
                
            </tr>
            
        </thead>
        
        <tbody>
            
            <tr>
                
          <td> NIC: </td>
          <td> Mobile No: </td>
          <td> Name: </td>
             
            </tr>
             <tr>
                
           
             
            </tr>
            
             <tr>
                
           
            </tr>
            
        </tbody>
        
    </table>
    
</div>