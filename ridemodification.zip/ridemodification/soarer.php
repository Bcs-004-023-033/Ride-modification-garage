<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
    <title>Ride Modification Garage</title>
    
<!--bootstrap-->
    
    <link type="text/css" rel="stylesheet" href="bootstrap-4.4.1-dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="style.css" />
    <link  rel="stylesheet" href="css/all.min.css" >
    <link rel="stylesheet" href="css/fontawesome.min.css">
   <link rel=stylesheet href="modify.css" />
   
    </head>
    <style>
    
    body,
html {
  height: 100%;
  margin: 0;
  padding: 0;
  font-size: 14px;
  color: #444444;
}
    </style>
    <body>
        <div>
        <?php include'header.php';?>
        </div>
      <?php include'button.php';?>
        
  <canvas id="c"></canvas>
      <script src="js/three.min.js"></script>
    <script src="GLTFLoader.js"></script>
    <script src="OrbitControls.js"></script> 
        
        
    
<div>    
  
    <script>
   
         
   
    
        
        
 var cameraFar = 50;
        var theModel;
const MODEL_PATH="model/soarer/soarer blue R1.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
        
        
            //RED//
        
      function myFunctionred() {
         var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer red R1.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
   
        }
        
        //GOLDEN//
        
          function myFunctiongold() {
         var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer gold R1.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
   
        }
        
        
        //SILVER//
        
        
          function myFunctionsilver() {
         var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer green R1.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
   
        }
        
        
        
        //BLACK //
        
          function myFunctionblack() {
         var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer black R1.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
   
        }
        
        
        //blue//
        
         function myFunctionblue() {
         var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer blue R1.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
   
        }
        
    //R1//
        
          function myFunctionr1() {
         var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer blue R1.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
   
        }
    
    
     // R3 
        
        function myFunctionr3() {
         var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer blue R3.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
   
        }
        
        
        //R5
        
        

    function myFunctionr5() {
 var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer blue R5.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
    }
    
    
  //R6  
   
   
    
        function myFunctionR6() {
 var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer blue R6.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
    }
   
        // rangerover //
        
                function myFunctionrange() {
 var cameraFar = 50;
        var theModel;
const MODEL_PATH ="blue rangeR R1.glb";
        const BACKGROUND_COLOR = 0x484a4d;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
    }
        
  function myFunctions2() {
 var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer blue s2.glb";
        const BACKGROUND_COLOR = 0x354e78;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
    }
    
    
  //R6  
   
   
    
        function myFunctions3() {
 var cameraFar = 50;
        var theModel;
const MODEL_PATH ="model/soarer/soarer blue s3.glb";
        const BACKGROUND_COLOR = 0x354e78;
     const scene = new THREE.Scene();
        scene.background = new THREE.Color(BACKGROUND_COLOR );
//scene.fog = new THREE.Fog(BACKGROUND_COLOR, 20, 100);
    const canvas = document.querySelector('#c');
    const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
   renderer.shadowMap.enabled = true;
renderer.setPixelRatio(window.devicePixelRatio); document.body.appendChild(renderer.domElement);
        var camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 1, 6000);
camera.position.z = cameraFar;
camera.position.x = 0;
        var loader = new THREE.GLTFLoader();
const INITIAL_MTL = new THREE.MeshPhongMaterial( { color: 0xffffff, shininess: 10 } );
loader.load(MODEL_PATH, function(gltf) {
  theModel = gltf.scene;
     theModel.traverse((o) => {
     if (o.isMesh) {
       o.castShadow = true;
       o.receiveShadow = true;
     }
   });
    theModel.scale.set(2,2,2);
    theModel.rotation.y = Math.PI/4;
         theModel.position.y = -1;
    scene.add(theModel);

}, undefined, function(error) {
  console.error(error)
});
        var hemiLight = new THREE.AmbientLight( 0x404040,100 );
    hemiLight.position.set( 0, 50, 0 );
        scene.add( hemiLight );

var dirLight = new THREE.DirectionalLight( 0xfffff5, 100 );
    dirLight.position.set( -0, 1, 0 );
    dirLight.castShadow = true;
    scene.add(dirLight);
     light = new THREE.PointLight(0xfffff5,10);
        light.position.set(0,300,500);
        scene.add(light);
        light2 = new THREE.PointLight(0xfffff5,10);
        light2.position.set(500,100,0);
        scene.add(light2);
        light3 = new THREE.PointLight(0xfffff5,10);
        light3.position.set(0,100,-500);
        scene.add(light3);
        light4 = new THREE.PointLight(0xfffff5,10);
        light4.position.set(-500,300,500);
        scene.add(light4);
    dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
   var floorGeometry = new THREE.PlaneGeometry(5000, 5000, 1, 1);
var floorMaterial = new THREE.MeshPhongMaterial({
  color: 0xe32424, // <------- Here
  shininess: 10
});

var floor = new THREE.Mesh(floorGeometry, floorMaterial);
floor.rotation.x =-0.5 * Math.PI;
floor.receiveShadow = true;
floor.position.y =-8;
scene.add(floor);
    var controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.maxPolarAngle = Math.PI / 2;
controls.minPolarAngle = Math.PI / 3;
controls.enableDamping = true;
controls.enablePan = false;
controls.dampingFactor = 0.1;
controls.autoRotate = true; // Toggle this if you'd like the chair to automatically rotate
controls.autoRotateSpeed = 0.5; // 30
   function animate() {
        controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
  
  if (resizeRendererToDisplaySize(renderer)) {
    const canvas = renderer.domElement;
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  }
}

animate();
        function resizeRendererToDisplaySize(renderer) {
  const canvas = renderer.domElement;
  var width = window.innerWidth;
  var height = window.innerHeight;
  var canvasPixelWidth = canvas.width / window.devicePixelRatio;
  var canvasPixelHeight = canvas.height / window.devicePixelRatio;

  const needResize = canvasPixelWidth !== width || canvasPixelHeight !== height;
  if (needResize) {
    
    renderer.setSize(width, height, false);
  }
  return needResize;
}
    }
    </script>
        </div>
  
    
        </body>
</html>