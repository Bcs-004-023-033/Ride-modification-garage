<?php

include("includes/db.php");
include("functions/functions.php");

?>

<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
    <title>Ride Modification Garage</title>
    
<!--bootstrap-->
    
    <link type="text/css" rel="stylesheet" href="bootstrap-4.4.1-dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="style.css" />
     <link type="text/css" rel="stylesheet" href="autostore.css" />
    <link  rel="stylesheet" href="css/all.min.css" >
    <link rel="stylesheet" href="css/fontawesome.min.css">
    
    </head>
    <body>
        <?php include'header.php';?>
       
       
       <div id="content">
           <div class="container">
               <div class="col-md-12">
                   
                 <ul class="breadcrumb">
                     <li>
                         <a href="autostore.php">Home</a>
                     </li>
                     <li>
                         <a href="autostore.php">Autostore</a>
                     </li>
                     <li>
                        Shop
                     </li>
                      <li>
                     
                    
                 </ul>  
                   
               </div>
               <div class="d-flex">
               <div class="col-md-3">
                   
                   <?php include'sidebar.php';?>
                   
               </div>
                              

         
              
              <div class="col-md-9">
                  <div id="productMain" class="row">
                     
                      <div class="col-sm-6" id="mainImage">
                        
              <div id="carousel" class="carousel slide" data-ride="carousel">
		<div class="carousel-inner">
			<div class="carousel-item active">
				<img class="img-fluid" src="admin/parts/636818620122234644.jpg" alt="First slide">
			</div>
			
		</div>
	</div>  
                      </div>
                      
                      <div class="col-sm-6">
                          <div class="box">
                              <h1 class="text-center"> <?php echo $pro_title; ?></h1>
                              
                              
                              <form action="autostore.php?add_cart=<?php echo $pro_id; ?>" class="form-horizontal" method="post">
                                  <div class="form-group"><label for="" class="col-md-5 control-label">Product Quantity</label>
                                  
                                  <div class="col-md-7">
                                         <select name="product_qty" id="" class="form-control">
                                          <option>1</option>
                                          <option>2</option>
                                          <option>3</option>
                                          <option>4</option>
                                          <option>5</option>
                                      </select>
                                      
                                      </div>
                                  
                                  </div>
                                  
                                  <div class="form-group">
                                      <label class="col-md-5 control-label">Make</label>
                                      
                                      <div class="col-md-7"><select name="make" id="" class="form-control">
                                          
                                        <option>Select Make</option> <option>Honda</option>
                                          <option>Toyota</option>
                                          <option>Corolla</option>
                                          <option>Suzuki</option>
                                          <option>Daihatsu</option>
                                          <option>Hyundai</option>
                                          
                                      </select>
                                      
                                      </div>
                                      
                                  </div>
                                  
                                  <p class="price">Pkr <?php echo $pro_price; ?></p>
                                  
                                  <p class="text-center buttons"><button class="btn btn-primary i fa fa-shopping-cart"> Add to Cart</button></p>
                                  
                              </form>
                          </div>
                         
                          <div class="row mx-auto thumbnails" id="thumbs">
                              
                              <div class="col-xs-4">
                              <a data-slide-to="0" href="#" class="thumb">
                              <img src="admin/parts/<?php echo $pro_img; ?>" alt="product 1" class="img-fluid img-thumbnail" width="20%" height="20%">
                              </a>
                             
                              <a data-slide-to="0" href="#" class="thumb">
                              <img src="admin/parts/<?php echo $pro_img; ?>" alt="product 2" class="img-fluid img-thumbnail" width="20%" height="20%">
                              </a>
                            
                              
                              
                              <a data-slide-to="0" href="#" class="thumb">
                              <img src="admin/parts/<?php echo $pro_img; ?>" alt="product 3" class="img-fluid img-thumbnail" width="20%" height="20%">
                              </a>
                              </div>
                              
                          </div>
                          
                          
                      </div>
                      
                      
                  </div>
                  
                  <div class="box" id="details">
                     
                     <h4>Product Details</h4>
                      
                      <p>
                          
                       <?php echo $pro_title;?>
                          
                      </p>
                      
                      <h4>Make</h4>
                      
                      <ul>
                          <li>Honda</li>
                          <li>Toyota</li>
                          <li>Suzuki</li>
                      </ul>
                      
                  </div>
                  
                  <div class="row same-height-row">
                      <div class="col-md-3 col-sm-6">
                          <div class="box same-height headline">
                              <h3 class="text-center">Products you may like</h3>
                          </div>
                      </div>
                      
                          
                          </div>
                      </div>
                      
                  </div>
                  
                  
              </div>
              
        </div>
               
           
      
        <?php include'footer.php';?>
        
        
        <script src="bootstrap-4.4.1-dist/js/bootstrap.min.js"></script>
        <script src="js/jquery.min.js"></script>
       
    </body>
    
    
</html> 