
  <div class="card">
       
       <div class="card-header">
           <h3 class="card-title">Product Categories</h3>
        
       </div>
    
       <ul class="list-group list-group-flush list-group-item" style="list-style-type:none">
           
             <?php  getPCats(); ?>
               
      
         
         
       </ul>
       
   </div>

  <div class="card">
       
       <div class="card-header">
           <h3 class="card-title">Categories</h3>
        
       </div>
       <ul class="list-group list-group-flush list-group-item" style="list-style-type:none">
         
            <?php  getCats(); ?>  
         
       </ul>
   </div>
<div class="card">
       
       <div class="card-header">
           <h3 class="card-title">Brands</h3>
        
       </div>
       <ul class="list-group list-group-flush">
           <li class="list-group-item"><a href="Shop.php">tyc</a></li>
          <li class="list-group-item"><a href="Shop.php">anker</a></li>
          <li class="list-group-item"><a href="Shop.php">memo</a></li>
          <li class="list-group-item"><a href="Shop.php">bullsone</a></li>
          <li class="list-group-item"><a href="Shop.php">total tool</a></li>
         
       </ul>
      
   </div>
<div class="card">
       
       <div class="card-header">
           <h3 class="card-title">Make</h3>
        
       </div>
       <ul class="list-group list-group-flush">
           <li class="list-group-item"><a href="Shop.php">honda</a></li>
          <li class="list-group-item"><a href="Shop.php">toyota</a></li>
          <li class="list-group-item"><a href="Shop.php">mercedes</a></li>
          <li class="list-group-item"><a href="Shop.php">daihatsu</a></li>
          <li class="list-group-item"><a href="Shop.php">suzuki</a></li>
          <li class="list-group-item"><a href="Shop.php">more...</a></li>
         
       </ul>
   </div>
<div class="card">
       
       <div class="card-header">
           <h3 class="card-title">Categories</h3>
        
       </div>
       <ul class="list-group list-group-flush">
           <li class="list-group-item"><a href="Shop.php">0-999</a></li>
          <li class="list-group-item"><a href="Shop.php">1000-2000</a></li>
          <li class="list-group-item"><a href="Shop.php">2001-3000</a></li>
          <li class="list-group-item"><a href="Shop.php">3001-4000</a></li>
          <li class="list-group-item"><a href="Shop.php">4001-5000</a></li>
           
         
       </ul>
       
   </div>