<center>
    
   <h1> Do You Really Want To Delete Your Account?</h1> 
   
   <form action="" method="post">
       
       <input type="submit" name="Yes" value="Yes, I Want To Delete" class="btn btn-danger">
       
        <input type="submit" name="No" value="Yes, I Dont Want To Delete" class="btn btn-primary">
   </form>
    
</center>