<?php

include("includes/db.php");
include("functions/functions.php");

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
    <title>Ride Modification Garage</title>
    
<!--bootstrap-->
    
    <link type="text/css" rel="stylesheet" href="bootstrap-4.4.1-dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="style.css" />
     <link type="text/css" rel="stylesheet" href="autostore.css" />
    <link  rel="stylesheet" href="css/all.min.css" >
    <link rel="stylesheet" href="css/fontawesome.min.css">
    
    </head>
    <body>
     
        <?php include'header.php';?>
      
      
       <div id="content">
           <div class="container">
               <div class="col-md-12">
                   
                 <ul class="breadcrumb">
                     <li>
                         <a href="autostore.php">Home</a>
                     </li>
                     <li>
                         <a href="autostore.php">Autostore</a>
                     </li>
                     <li>
                       Shop
                     </li>
                     
                    
                 </ul>  
                   
               </div>
               <div class="d-flex">
               <div class="col-md-3">
                   
                   <?php include'sidebar.php';?>
                   
               </div>
                              

               <div class="col-md-9">
                 
                 
                  
                   <div class='box'>
                       <h1>SHOP</h1>
                       <p>Here you can find parts with best possible price ever.</p>
                   </div>
                   
                 
                   <div class="row">
                       
                       <div class="col-md-4 col-sm-6 mx-auto">
                           
                           <div class="product">
                               
                               <a href="details.php">
                                   
                                   <img src="admin/parts/636818620122234644.jpg" class="img-fluid">
                                   
                               </a>
                               
                               <div class="text">
                                   
                                   <h3><a href="details.php">Indicator lights-pair</a></h3>
                                   
                                   <p class="price">Pkr 1000</p>
                                   
                                   <p class="buttons">
                                      <center> 
                                       <a href="details.php" class="btn btn-default">View Details
                                       </a>
                                       
                                        <a href="details.php" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Add to Cart
                                       </a>
                                       </center>
                                   </p>
                                   
                               </div>
                                                                                                                                                 
                           </div>
                           
                           
                       </div>
                       
                       
                       <div class="col-md-4 col-sm-6">
                           
                           <div class="product">
                               
                               <a href="details.php">
                                   
                                   <img src="admin/parts/636818620122234644.jpg" class="img-fluid">
                                   
                               </a>
                               
                               <div class="text">
                                   
                                   <h3><a href="details.php">Indicator lights-pair</a></h3>
                                   
                                   <p class="price">Pkr 1000</p>
                                   
                                   <p class="buttons">
                                      <center> 
                                       <a href="details.php" class="btn btn-default">View Details
                                       </a>
                                       
                                        <a href="details.php" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Add to Cart
                                       </a>
                                       </center>
                                   </p>
                                   
                               </div>
                               
                           </div>
                           
                           
                       </div>
                       
                       <div class="col-md-4 col-sm-6">
                           
                           <div class="product">
                               
                               <a href="details.php">
                                   
                                   <img src="admin/parts/636818620122234644.jpg" class="img-fluid">
                                   
                               </a>
                               
                               <div class="text">
                                   
                                   <h3><a href="details.php">Indicator lights-pair</a></h3>
                                   
                                   <p class="price">Pkr 1000</p>
                                   
                                   <p class="buttons">
                                      <center> 
                                       <a href="details.php" class="btn btn-default">View Details
                                       </a>
                                       
                                        <a href="details.php" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Add to Cart
                                       </a>
                                       </center>
                                   </p>
                                   
                               </div>
                               
                           </div>
                           
                           
                       </div>
                       
                       <div class="col-md-4 col-sm-6">
                           
                           <div class="product">
                               
                               <a href="details.php">
                                   
                                   <img src="admin/parts/636818620122234644.jpg" class="img-fluid">
                                   
                               </a>
                               
                               <div class="text">
                                   
                                   <h3><a href="details.php">Indicator lights-pair</a></h3>
                                   
                                   <p class="price">Pkr 1000</p>
                                   
                                   <p class="buttons">
                                      <center> 
                                       <a href="details.php" class="btn btn-default">View Details
                                       </a>
                                       
                                        <a href="details.php" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Add to Cart
                                       </a>
                                       </center>
                                   </p>
                                   
                               </div>
                               
                           </div>
                           
                           
                       </div>
                       
                       <div class="col-md-4 col-sm-6">
                           
                           <div class="product">
                               
                               <a href="details.php">
                                   
                                   <img src="admin/parts/636818620122234644.jpg" class="img-fluid">
                                   
                               </a>
                               
                               <div class="text">
                                   
                                   <h3><a href="details.php">Indicator lights-pair</a></h3>
                                   
                                   <p class="price">Pkr 1000</p>
                                   
                                   <p class="buttons">
                                      <center> 
                                       <a href="details.php" class="btn btn-default">View Details
                                       </a>
                                       
                                        <a href="details.php" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Add to Cart
                                       </a>
                                       </center>
                                   </p>
                                   
                               </div>
                               
                           </div>
                           
                           
                       </div>
                       
                       <div class="col-md-4 col-sm-6">
                           
                           <div class="product">
                               
                               <a href="details.php">
                                   
                                   <img src="admin/parts/636818620122234644.jpg" class="img-fluid">
                                   
                               </a>
                               
                               <div class="text">
                                   
                                   <h3><a href="details.php">Indicator lights-pair</a></h3>
                                   
                                   <p class="price">Pkr 1000</p>
                                   
                                   <p class="buttons">
                                      <center> 
                                       <a href="details.php" class="btn btn-default">View Details
                                       </a>
                                       
                                        <a href="details.php" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Add to Cart
                                       </a>
                                       </center>
                                   </p>
                                   
                               </div>
                               
                           </div>
                           
                           
                       </div>
                       
                       <div class="col-md-4 col-sm-6">
                           
                           <div class="product">
                               
                               <a href="details.php">
                                   
                                   <img src="admin/parts/636818620122234644.jpg" class="img-fluid">
                                   
                               </a>
                               
                               <div class="text">
                                   
                                   <h3><a href="details.php">Indicator lights-pair</a></h3>
                                   
                                   <p class="price">Pkr 1000</p>
                                   
                                   <p class="buttons">
                                      <center> 
                                       <a href="details.php" class="btn btn-default">View Details
                                       </a>
                                       
                                        <a href="details.php" class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Add to Cart
                                       </a>
                                       </center>
                                   </p>
                                   
                               </div>
                               
                           </div>
                           
                           
                       </div>
                       
                       
                       
                   </div>
               
      
          
          <nav aria-label="Page navigation example">
       <ul class="pagination  justify-content-center">
           <li class="page-item"><a class="page-link" href="shop.php">First Page</a></li>
           <li class="page-item"><a class="page-link" href="shop.php">2</a></li>
           <li class="page-item"><a class="page-link" href="shop.php">3</a></li>
           <li class="page-item"><a class="page-link" href="shop.php">4</a></li>
           <li class="page-item"><a class="page-link" href="shop.php">5</a></li>
           <li class="page-item"><a class="page-link" href="shop.php">Last Page</a></li>
       </ul>
   </nav>
          
          
     

   
    
            
                      </div>
               </div>
               
           </div>
       </div>
       
       
      
        <?php include'footer.php';?>
        
        
        <script src="bootstrap-4.4.1-dist/js/bootstrap.min.js"></script>
        <script src="js/jquery.min.js"></script>
       
    </body>
    
    
</html> 