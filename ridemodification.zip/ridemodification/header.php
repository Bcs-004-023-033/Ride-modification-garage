<?php

if(isset($_GET['pro_id'])){
    
    $product_id=$_GET['pro_id'];
    
    $get_product="select * from products where product_id=$product_id";
    
    $run_product=mysqli_query($con, $get_product);
    
    $row_product=mysqli_fetch_array($run_product);
    
    $p_cat_id=$row_product['p_cat_id'];
    
    $pro_brand= $row_product['product_brand'];
    
    $pro_title= $row_product['product_id'];
   
    $pro_price= $row_product['product_price'];
    
    $pro_make= $row_product['product_make'];
    
    $pro_desc= $row_product['product_desc'];
    
    $pro_img= $row_product['product_img'];
    
    $get_p_cat="select * from product_categories where p_cat_id='$p_cat_id'";
    
    $run_p_cat=mysqli_query($con,$get_p_cat);
    
    $row_p_cat=mysqli_fetch_array($run_p_cat);
    
    $p_cat_title= $row_p_cat['p_cat_title'];
    
}

?>
   

   
   
   <head>
    <style>
    
    /*top menu*/
#top {
	background: #555555;
    padding: 10px 0;
}
#top .offer{
	color: #ffffff;
      font-size: 12px;  
}
#top .offer .btn{
    text-transform: uppercase;
    font-size: 12px;
}
@media(max-width: 991px){
    #top {
	font-size: 12px;
        text-align: center;
}
    #top .offer{
        margin-bottom: 10px;
    }
}
#top a {
	color: #ffffff;
}
#top #reg{
    float: right;
    margin-left: 15px;
    margin-top: 0px;
    font-size: 12px;
}
    
    </style>
</head>
          

            <div id="top">
           
           <div class="container">
               <div class="col-md-6" style="float:right">
                   <a href="cart.php" id="reg" class="btn navbar-btn btn-primary btn-sm"><i class="fas fa-shopping-cart"></i><span>Cart</span></a>
             <a href="account.php" id="reg" class="btn navbar-btn btn-primary btn-sm"><i class="fas fa-user"></i><span>Account</span></a>
                   <a href="register.php" class="btn btn-danger btn-sm" id="reg">Register</a>
                   
               </div>
              
                       <div class="col-md-6 offer">
                           
                           <a href="contact.php" class="btn btn-success btn-sm">Contact Us</a>
                           <a href="#">Its' time to Fulfil your car needs...</a>
                            
                       </div>
              
                
           </div>
       </div>
     <div class="header-wrapper">
        <div class="logo-icon-wrapper">
            <div class="logo">
       <a href="home.php"> <img src="images/logo%203d.png" alt="Ride Modification Garage">
               </a> 
                </div>
              
          <div class="navigation">
            
             <ul>
             <li><a href="home.php">HOME</a></li>
             <li><a href="modify.php">MODIFY CAR</a></li>
                 
                 <div class="dropdown">
               <li><a href="autostore.php">AUTOSTORE<i class="fas fa-caret-down"></i></a> </li>
                 <div class="dropdown-content">
                    <p><a href="shop.php">SHOP</a></p>
                     <p><a href="exterior.php">EXTERIOR</a></p>
                    <p><a href="interior.php">INTERIOR</a></p> 
                    <p><a href="wraps.php">WRAPS</a></p> 
                    <p><a href="lights.php">LIGHTS</a></p> 
                    <p><a href="gadgets.php">GADGETS</a></p> 
                   
                 </div>
                
                 </div> 
                 
             <li><a href="ridegallery.php">RIDES GALLERY</a></li>
                 <li><a href="login.php">LOGIN</a></li>
             <li><a href="help.php">HELP</a></li>
             
             </ul>
             
             </div>
        
         </div>
      
        </div>
      


                   <!--        <div class='col-md-4 col-sm-6 mx-auto'>
                                    
                                    <div class='product'>
                                    
                                    <a href='details.php?pro_id= $pro_id'>  
                                    <img class='img-fluid' src='admin/parts/exterior/$pro_img'>
                                    
                                    
                                    
                                    </a>
                                    
                                    <div class='text'>
                                    
                                    <h3>
                                    
                                    <a href='details.php'?pro_id=$pro_id> $pro_title </a>
                                    
                                    </h3>
                                    
                                    <p class='price'>
                                    
                                    $$pro_price                        
                                    </p>
                                    
                                     <p class='button'>
                                    
                                  <a class='btn btn-default' href='details.php'?pro_id=$pro_id> 
                                  
                                  View Details
                                  
                                  </a>   
                                  
                                   <a class='btn btn-primary' href='details.php'?pro_id=$pro_id> 
                                  
                               <i class='fa fa-shopping-cart'></i>  Add To Cart
                                  
                                  </a>                 
                                  
                                    </p>
                                    
                                    </div>
                                    
                                    </div>
                                    
                                    </div>-->
                                    
