<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
    <title>Ride Modification Garage</title>
    
<!--bootstrap-->
    
    <link type="text/css" rel="stylesheet" href="bootstrap-4.4.1-dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="style.css" />
    <link  rel="stylesheet" href="css/all.min.css" >
    <link rel="stylesheet" href="css/fontawesome.min.css">
    
    
    
    <!--colorswitcher-->
    
    <link rel="stylesheet" id="switcher-css" type="text/css" href="colorswitcher/switcher.css" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="colorswitcher/blue.css" media="all" data-default-color="true" />
    <link rel="alternate stylesheet" type="text/css" href="colorswitcher/green.css" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="colorswitcher/orange.css" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="colorswitcher/pink.css" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="colorswitcher/purple.css" media="all" />
    <link rel="alternate stylesheet" type="text/css" href="colorswitcher/red.css" media="all" />
    <!--/colorswitcher-->
</head>
<body>
<?php include'header.php';?>
    <!--/headersection-->
    <div class="slider_image">
    <div class="main_image">
        <img src="images/wall2.jpg">
         <div class="text-block">
    <h4>Try it!Before you buy it...</h4>
    <p>A perfect store for you</p>
    <p>A complete garage at one platform</p>
  </div>
        <div class="search-sec">
    <div class="container">
        <form action="#" method="post" novalidate="novalidate">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                            <input type="text" class="form-control search-slt" placeholder="Select Option to Search">
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                            <input type="text" class="form-control search-slt" placeholder="Make">
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                            <select class="form-control search-slt" id="exampleFormControlSelect1">
                                <option>Select Vehicle</option>
                                <option>Civic</option>
                                <option>Buggati</option>
                                <option>Range Rover</option>
                                <option>Gwagon</option>
                                <option>Gli</option>
                                <option><a href="modify.php">more for modification</a></option>
                                <option><a href="ridegallery.php">more cars to see</a></option>
                            </select>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                            <button type="button" class="btn btn-danger wrn-btn">Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
        </div>
    </div>
    
    <!--modify section-->
    
    <div class="modify_pic">
    <div class="modify_wrapper">
        <div>
        <span><i class="fas fa-angle-double-down"></i></span><h2>CARS FOR MODIFICATION:</h2>
        
        </div>
        <div class="pics">
        <div class="first">
        <a href="bmw5.php">
            <img src="images/modifysec/h1.jpg">
            <span>BMW 5SERIES</span>
            </a>
        </div>
            <div class="second">
        <a href="modify.php">
            <img src="images/modifysec/h2.jpg">
            <span>COROLLA</span>
            </a>
        </div>
            <div class="third">
        <a href="buggati.php">
            <img src="images/modifysec/h3.jpg">
            <span>SWIFT</span>
            </a>
        </div>
            <div class="fourth">
        <a href="range.php">
            <img src="images/modifysec/h4.jpg">
            <span>Range Rover</span>
            </a>
        </div>
            <div class="fifth">
        <a href="sportage.php">
            <img src="images/modifysec/h5.jpg">
            <span>SPORTAGE</span>
            </a>
        </div>
          
        </div>
        </div>
    
    
    </div>
    
    
    <!--autostore section-->
    <div class="autostore">
    <div class="auto_heading">
        <span><i class="fas fa-angle-double-down"></i></span><h2>AUTOSTORE:</h2>
        </div>
    <div class="auto_pics">
        <div class="first">
        <a href="#">
            <img src="images/parts/exterior/mirror.jpg" id="img">
            <div class="overly-auto">
                <div class="overly-wrapper">
               <button type="button" class="btn btn-secondary" title="quick shop"><i class="fa fa-eye"></i></button>
                <button type="button" class="btn btn-secondary" title="add to wishlist"><i class="fa fa-heart"></i></button>
                <button type="button" class="btn btn-secondary" title="add to cart"><i class="fa fa-shopping-cart"></i></button>
                </div>
                
            </div>
            </a>
        </div>
        <div class="second">
            <a href="#">
            <img src="images/parts/interior/int.jpg" id="img">
            <div class="overly-auto">
                <div class="overly-wrapper">
                     <button type="button" class="btn btn-secondary" title="quick shop"><i class="fa fa-eye"></i></button>
                <button type="button" class="btn btn-secondary" title="add to wishlist"><i class="fa fa-heart"></i></button>
                <button type="button" class="btn btn-secondary" title="add to cart"><i class="fa fa-shopping-cart"></i></button>
                </div>
            </div>
            </a>
        </div>
        <div class="third">
            <a href="#">
            <img src="images/parts/wraps/main.jpg" id="img">
            <div class="overly-auto">
                <div class="overly-wrapper">
                <button type="button" class="btn btn-secondary" title="quick shop"><i class="fa fa-eye"></i></button>
                <button type="button" class="btn btn-secondary" title="add to wishlist"><i class="fa fa-heart"></i></button>
                <button type="button" class="btn btn-secondary" title="add to cart"><i class="fa fa-shopping-cart"></i></button>
                </div>
            </div>
            </a>
        </div>
        <div class="fourth">
            <a href="#">
            <img src="images/parts/lights/main1.jpg" id="img">
            <div class="overly-auto">
                <div class="overly-wrapper">
                <button type="button" class="btn btn-secondary" title="quick shop"><i class="fa fa-eye"></i></button>
                <button type="button" class="btn btn-secondary" title="add to wishlist"><i class="fa fa-heart"></i></button>
                <button type="button" class="btn btn-secondary" title="add to cart"><i class="fa fa-shopping-cart"></i></button>
                </div>
            </div>
            </a>
        </div>
         <div class="fifth">
            <a href="#">
            <img src="images/parts/gadgets/main.jpeg" id="img">
            <div class="overly-auto">
                <div class="overly-wrapper">
                 <button type="button" class="btn btn-secondary" title="quick shop"><i class="fa fa-eye"></i></button>
                <button type="button" class="btn btn-secondary" title="add to wishlist"><i class="fa fa-heart"></i></button>
                <button type="button" class="btn btn-secondary" title="add to cart"><i class="fa fa-shopping-cart"></i></button>
                    <h3>Exterior</h3>
                </div>
            </div>
            </a>
        </div>
    </div>
    </div>
    
    <!--rides gallery-->
    
    <div class="gallery_pic">
    <div class="gallery_wrapper">
        <div>
        <span><i class="fas fa-angle-double-down"></i></span><h2>RIDES GALLERY:</h2>
        
        </div>
        <div class="pics">
        <div class="first">
        <a href="ridegallery.php">
            <img src="images/modifysec/r1.jpg">
            <span>HONDA</span>
            </a>
        </div>
            <div class="second">
        <a href="ridegallery.php">
            <img src="images/modifysec/r2.jpg">
            <span>MERCEDES</span>
            </a>
        </div>
            <div class="third">
        <a href="ridegallery.php">
            <img src="images/modifysec/r3.jpg">
            <span>NISSAN</span>
            </a>
        </div>
            <div class="fourth">
        <a href="ridegallery.php">
            <img src="images/modifysec/r4.jpg">
            <span>CH-R</span>
            </a>
        </div>
            <div class="fifth">
        <a href="ridegallery.php">
            <img src="images/modifysec/r5.jpg">
            <span>PRADO</span>
            </a>
        </div>
          
        </div>
        </div>
    
    
    </div>
    
    <!--website features-->
    
    <div class="website-features">
    
    <div class="conatiner">
        <div class="auto_heading">
        <div>
        <span><i class="fas fa-angle-double-down"></i></span><h2>FEATURES:</h2>
        </div>
            </div>
        <div class="row">
        
        <div class="col-md-3 feature-box">
            
            <img src="images/features/feature1.png">
            <div class="feature-text">
            <p><b>100% Original items </b>are available at company.</p>
            
            </div>
            </div>
         <div class="col-md-3 feature-box">
            
            <img src="images/features/feature2.png">
            <div class="feature-text">
            <p><b>Return within 30 days </b>of receiving your order.</p>
            
            </div>
            </div>
             <div class="col-md-3 feature-box">
            
            <img src="images/features/feature3.png">
            <div class="feature-text">
            <p><b>Get your order </b>in 7 working days.</p>
            
            </div>
            </div>
             <div class="col-md-3 feature-box">
            
            <img src="images/features/feature4.png">
            <div class="feature-text">
            <p><b>Cash on delivery </b>on your satisfaction.</p>
            
            </div>
            </div>
        </div>
        
        </div>
    
    </div>
    <!--footer-->
    <?php include'footer.php';?>

    <script src="js/jquery.min.js"></script>
    <script src="bootstrap-4.4.1-dist/js/bootstrap.min.js"></script>
    <script src="js/interface.js"></script>
    
<script src="colorswitcher/switcher.js"></script>
    

</body>
  