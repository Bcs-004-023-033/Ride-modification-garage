<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
    <title>Ride Modification Garage</title>
    
<!--bootstrap-->
    
    <link type="text/css" rel="stylesheet" href="bootstrap-4.4.1-dist/css/bootstrap.min.css" />
    <link type="text/css" rel="stylesheet" href="style.css" />
    <link  rel="stylesheet" href="css/all.min.css" >
    <link rel="stylesheet" href="css/fontawesome.min.css">
    <link rel="stylesheet" href="gallery.css" />
    <link rel="stylesheet" href="js/baguetteBox.min.css" />
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>    
    </head>
    <body>
        <?php include'header.php';?>
        
        <div class="gallery-block cards-gallery">
        <div class="container">
            <div class="heading">
           
            
            </div>
            <div class="row">
            <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p1.jpg"><img src="images/ridesgallery/p1.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">23 lac</p>
                    <p class="text-muted card-text">AQUA</p>
                    <p class="text-muted card-text">2015</p>
                    <p class="text-muted card-text">Automatic</p>
                    </div>
                
                </div>
                
                </div>
                <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p2.jpg"><img src="images/ridesgallery/p2.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>HONDA</h6>
                    <p class="text-muted card-text">45 lac</p>
                    <p class="text-muted card-text">VEZEL</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    </div>
                
                </div>
                
                </div>
                <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p3.jpg"><img src="images/ridesgallery/p3.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>LAMBORGHINI</h6>
                    <p class="text-muted card-text">800 lac</p>
                    <p class="text-muted card-text">Aventador</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    </div>
                
                </div>
                
                </div>
                <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p4.jpg"><img src="images/ridesgallery/p4.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">48 lac</p>
                    <p class="text-muted card-text">premio</p>
                    <p class="text-muted card-text">2019</p>
                    <p class="text-muted card-text">Automatic</p>
                    </div>
                
                </div>
                </div>
                <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p5.jpg"><img src="images/ridesgallery/p5.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">18 lac</p>
                    <p class="text-muted card-text">Alto </p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                    </div>
                    
                  </div>  
                </div>
             <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p6.jpg"><img src="images/ridesgallery/p6.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>HONDA</h6>
                    <p class="text-muted card-text">105 lac</p>
                    <p class="text-muted card-text">Accord</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                    </div>
            </div>
            </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p7.jpg"><img src="images/ridesgallery/p7.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">55 lac</p>
                    <p class="text-muted card-text">Prado</p>
                    <p class="text-muted card-text">2008</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>   
              </div>
                      
            </div>
         
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p8.jpg"><img src="images/ridesgallery/p8.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>HONDA</h6>
                    <p class="text-muted card-text">40 lac</p>
                    <p class="text-muted card-text">Civic</p>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>   
        </div>
                      
          </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p9.jpg"><img src="images/ridesgallery/p9.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">23 lac</p>
                    <p class="text-muted card-text">corolla</p>
                    <p class="text-muted card-text">2014</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                    </div>
                
                </div>
                
                </div>
                <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p10.jpg"><img src="images/ridesgallery/p10.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>MERCEDES</h6>
                    <p class="text-muted card-text">13 lac</p>
                    <p class="text-muted card-text">E200</p>
                    <p class="text-muted card-text">1990</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                    </div>
                
                </div>
                
                </div>
                <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p11.jpg"><img src="images/ridesgallery/p11.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">60 lac</p>
                    <p class="text-muted card-text">Prius</p>
                    <p class="text-muted card-text">2016</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                    </div>
                
                </div>
                
                </div>
                <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p12.jpg"><img src="images/ridesgallery/p12.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">25 lac</p>
                    <p class="text-muted card-text">Vitz</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                    </div>
                </div>
                </div>
                 <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p13.jpg"><img src="images/ridesgallery/p13.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>MERCEDES</h6>
                    <p class="text-muted card-text">155 lac</p>
                    <p class="text-muted card-text">E class</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                    </div>
                    
                  </div>  
                </div>
             <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p14.jpg"><img src="images/ridesgallery/p14.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">15 lac</p>
                    <p class="text-muted card-text">Alto</p>
                    <p class="text-muted card-text">2015</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                    </div>
            </div>
            </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p15.jpg"><img src="images/ridesgallery/p15.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">9 lac</p>
                    <p class="text-muted card-text">Mehran</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Manual</p>
                    
                </div>   
              </div>
                      
            </div>
         
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p16.jpg"><img src="images/ridesgallery/p16.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">20 lac</p>
                    <p class="text-muted card-text">Swift</p>
                    <p class="text-muted card-text">2019</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>   
        </div>
                </div>
         
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p17.jpg"><img src="images/ridesgallery/p17.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>Toyota</h6>
                    <p class="text-muted card-text">27 lac</p>
                    <p class="text-muted card-text">Corolla</p>
                    <p class="text-muted card-text">2019</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>                
            </div>
                       </div>
         
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p18.jpg"><img src="images/ridesgallery/p18.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>HONDA</h6>
                    <p class="text-muted card-text">25 lac</p>
                    <p class="text-muted card-text">City</p>
                    <p class="text-muted card-text">2019</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>   
            </div>
                </div>
         
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p19.jpg"><img src="images/ridesgallery/p19.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>HONDA</h6>
                    <p class="text-muted card-text">16 lac</p>
                    <p class="text-muted card-text">Airwave</p>
                    <p class="text-muted card-text">2014</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>          
        </div>
               </div>
         
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p20.jpg"><img src="images/ridesgallery/p20.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">14 lac</p>
                    <p class="text-muted card-text">WagonR</p>
                    <p class="text-muted card-text">2015</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
           <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p21.jpg"><img src="images/ridesgallery/p21.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>FAW</h6>
                    <p class="text-muted card-text">14 lac</p>
                    <p class="text-muted card-text">V2</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Manual</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p22.jpg"><img src="images/ridesgallery/p22.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">42 lac</p>
                    <p class="text-muted card-text">Jimny</p>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">Manual</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p23.jpg"><img src="images/ridesgallery/p23.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>HONDA</h6>
                    <p class="text-muted card-text">27 lac</p>
                    <p class="text-muted card-text">CIVIC</p>
                    <p class="text-muted card-text">2016</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p24.jpg"><img src="images/ridesgallery/p24.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">55 lac</p>
                    <p class="text-muted card-text">HIACE</p>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p25.jpg"><img src="images/ridesgallery/p25.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>MERCEDES</h6>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">E CLASS</p>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p26.jpg"><img src="images/ridesgallery/p26.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>HONDA</h6>
                    <p class="text-muted card-text">18 lac</p>
                    <p class="text-muted card-text">ACCORD</p>
                    <p class="text-muted card-text">2004</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p27.jpg"><img src="images/ridesgallery/p27.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">15 lac</p>
                    <p class="text-muted card-text">ALTO</p>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p28.jpg"><img src="images/ridesgallery/p28.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">54 lac</p>
                    <p class="text-muted card-text">VITARA</p>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p29.jpg"><img src="images/ridesgallery/p29.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">8 lac</p>
                    <p class="text-muted card-text">BALENO</p>
                    <p class="text-muted card-text">2006</p>
                    <p class="text-muted card-text">Manual</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p30.jpg"><img src="images/ridesgallery/p30.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">14 lac</p>
                    <p class="text-muted card-text">HUSTLER</p>
                    <p class="text-muted card-text">2017</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p31.jpg"><img src="images/ridesgallery/p32.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">50</p>
                    <p class="text-muted card-text">CH-R</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p33.jpg"><img src="images/ridesgallery/p33.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">86 lac</p>
                    <p class="text-muted card-text">FORTUNER</p>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p34.jpg"><img src="images/ridesgallery/p34.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">12 lac</p>
                    <p class="text-muted card-text">Corolla</p>
                    <p class="text-muted card-text">2007</p>
                    <p class="text-muted card-text">Manual</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p35.jpg"><img src="images/ridesgallery/p35.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">16 lac</p>
                    <p class="text-muted card-text">MARK 2</p>
                    <p class="text-muted card-text">2004</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p36.jpg"><img src="images/ridesgallery/p36.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>LEXUS</h6>
                    <p class="text-muted card-text">470 lac</p>
                    <p class="text-muted card-text">LX 570</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p37.jpg"><img src="images/ridesgallery/p37.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>TOYOTA</h6>
                    <p class="text-muted card-text">60 lac</p>
                    <p class="text-muted card-text">MARK X</p>
                    <p class="text-muted card-text">2017</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p38.jpg"><img src="images/ridesgallery/p38.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">10 lac</p>
                    <p class="text-muted card-text">BOLAN</p>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">Manual</p>
                    
                </div>           
        </div> </div>
                
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p39.jpg"><img src="images/ridesgallery/p39.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>SUZUKI</h6>
                    <p class="text-muted card-text">13 lac</p>
                    <p class="text-muted card-text">EVERY</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p40.jpg"><img src="images/ridesgallery/p40.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>DAIHATSU</h6>
                    <p class="text-muted card-text">14 lac</p>
                    <p class="text-muted card-text">MIRA</p>
                    <p class="text-muted card-text">2015</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p41.jpg"><img src="images/ridesgallery/p41.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>NISSAN</h6>
                    <p class="text-muted card-text">17 lac</p>
                    <p class="text-muted card-text">DAYS</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p42.jpg"><img src="images/ridesgallery/p42.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>HONDA</h6>
                    <p class="text-muted card-text">18 lac</p>
                    <p class="text-muted card-text">N WAGON</p>
                    <p class="text-muted card-text">2018</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p43.jpg"><img src="images/ridesgallery/p43.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>NISSAN</h6>
                    <p class="text-muted card-text">350 lac</p>
                    <p class="text-muted card-text">PATROL</p>
                    <p class="text-muted card-text">2020</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                  <div class="col-md-6 col-lg-3">
                <div class="card border-0 transform-on-hover">
                <a class="lightbox" href="images/ridesgallery/p44.jpg"><img src="images/ridesgallery/p44.jpg" class="card-img-top"></a>
                <div class="card-body">
                    
                    <h6>HONDA</h6>
                    <p class="text-muted card-text">10 lac</p>
                    <p class="text-muted card-text">CIVIC</p>
                    <p class="text-muted card-text">2006</p>
                    <p class="text-muted card-text">Automatic</p>
                    
                </div>           
        </div> </div>
                
      
            </div>
            </div>
    
        </div>
    
        <script>
        baguetteBox.run('.cards-gallery',{animation:'slideIn'});
        
        
        </script>
        <?php include'footer.php';?>
        
    </body>
</html>